function ulam() {
  let input_numero = document.getElementById("inputNum1");
  let valor_salida = document.getElementById("valor_salida");
  let numero = parseInt(input_numero.value);
  let secuencia = "";

  if (!isNaN(numero)) {
    // Verificar que el número inicial sea un entero positivo
    if (numero <= 0) {
      return;
    }
    // Inicializar la serie con el primer número
    let serie = [numero];
    // Generar la serie de Ulam
    while (numero !== 1) {
      if (numero % 2 === 0) {
        // Número par: dividir por 2
        numero /= 2;
      } else {
        // Número impar: multiplicar por 3 y sumar 1
        numero = 3 * numero + 1;
      }
      // Agregar el número a la serie
      serie.push(numero);
    }

    serie.forEach(function(elemento, indice) {
      secuencia += elemento + "-";
    });

    valor_salida.innerHTML = secuencia.substring(0,secuencia.length - 1);

  }


}
